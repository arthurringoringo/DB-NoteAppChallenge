# DB-NoteAppChallenge


THERE ARE 2 APPS IN THIS FILES
1st. The Polls app
2nd. The Notes app

To run the website : Run it with django *(python manage.py runserver)*
To view the apps go to the following URL
* Polls: http://localhost:8000/polls
* Notes: http://localhost:8000/notes